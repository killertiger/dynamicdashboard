CREATE PROCEDURE sgp_ilumno.InsGen(IN in_db VARCHAR(100), IN in_table VARCHAR(100), IN myquery VARCHAR(2000))
  BEGIN

    declare Whrs varchar(10000);
    declare Sels varchar(10000);
    declare Inserts varchar(65535);
    declare tablename varchar(100);

    set tablename=in_table;
    select tablename;
    # Comma separated column names – used for Select
    select group_concat(concat('concat('"',',if(column_name = 'client_unit_id' OR column_name = 'client_group_id', '"NULL"', CONCAT('ifnull(`',column_name,'`,"NULL")')),','"')')) INTO @Sels from information_schema.columns where table_schema=in_db and table_name=tablename;

    # Comma separated column names – used for Group By
    select group_concat('`',column_name,'`') INTO @Whrs from information_schema.columns where table_schema=in_db and table_name=tablename;

    #Main Select Statement for fetching comma separated table values
--    set @Inserts=concat("select concat('insert into ", in_db,".",tablename," values(',concat_ws(',',",@Sels,"),');') from ", in_db,".",tablename," group by ",@Whrs, " INTO OUTFILE '", in_file ,"'");
    set @Inserts=concat("select concat('insert into ", tablename,"(",@Whrs,") values(',concat_ws(',',",@Sels,"),');') from ", myquery," group by ",@Whrs);

    SELECt @Inserts;
    -- PREPARE Inserts FROM @Inserts;
    -- EXECUTE Inserts;

  END;
