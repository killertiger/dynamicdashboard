CREATE FUNCTION sgp_ilumno.fn_retorna_multiplos_conteudos(v_key_content INT)
  RETURNS VARCHAR(1000)
  begin
  
declare conteudos varchar(1000);
declare conteudo varchar (200);

    declare cconteudos cursor for 
    select co.name 
    from sgp_structure_content co 
        inner join sgp_structure_contentconfig cc on cc.`key` = co.content_config_id
        inner join sgp_structure_contentassessment ca on ca.content_id = co.`key` 
    where 
            cc.order = 4 and ca.assessment_item_id = v_key_content;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET conteudos = '';

    SET conteudos = '';
    open cconteudos;
    fetch cconteudos into conteudo;
        if (conteudos='') then
          set conteudos = conteudo;
        else 
          set conteudos = concat(conteudos, ' - ', conteudo);
        end if;

    close cconteudos;

    return conteudos;

end;
