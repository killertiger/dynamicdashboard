CREATE FUNCTION sgp_ilumno.fn_remove_htmltags(Dirty VARCHAR(8000))
  RETURNS VARCHAR(8000)
  BEGIN
  DECLARE iStart, iEnd, iLength int;
    WHILE Locate( '<', Dirty ) > 0 And Locate( '>', Dirty, Locate( '<', Dirty )) > 0 DO
      BEGIN
        SET iStart = Locate( '<', Dirty ), iEnd = Locate( '>', Dirty, Locate('<', Dirty ));
        SET iLength = ( iEnd - iStart) + 1;
        IF iLength > 0 THEN
          BEGIN
            SET Dirty = Insert( Dirty, iStart, iLength, '');
          END;
        END IF;
      END;
    END WHILE;

    SET Dirty = REPLACE(REPLACE(Dirty,char(13),'-'),char(10),'-');

    RETURN Dirty;
END;
